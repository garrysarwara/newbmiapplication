package com.cda.kursi.mynewbmiapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by kursi on 3/20/2016.
 */
public class CalculateBmi extends Activity{
    EditText h,w;
    TextView ans;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.displaybmi);
        Button bmi = (Button) findViewById(R.id.btnbm);
        ans = (TextView) findViewById(R.id.textView2);
        h= (EditText) findViewById(R.id.editText3);
        w= (EditText) findViewById(R.id.editText4);
        bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (  ( !h.getText().toString().equals("")) && ( !w.getText().toString().equals(""))) {
                    Double a, b, c;
                    a = Double.parseDouble(h.getText().toString());
                    b = Double.parseDouble(w.getText().toString());
                    c = b / (a * a);
                    ans.setText(" " + c);
                }
            }    });
    }

}
